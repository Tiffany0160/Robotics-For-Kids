document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    const testButtons = document.querySelectorAll('.test-btn');

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = this.querySelector('input[name="username"]').value;
        const password = this.querySelector('input[name="password"]').value;
        // You can add your login logic here
        console.log('Username:', username);
        console.log('Password:', password);
        this.reset();
        window.location.href = "chapters.html";
    });
    
// Login function
document.getElementById('login-form').addEventListener('submit', function (event) {
  event.preventDefault();

  const email = event.target['username'].value;
  const password = event.target['password'].value;
  const userRole = event.target['user-role'].value; // Get the selected role

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      alert('Login successful!');

      // Check the role and redirect accordingly
      if (userRole === 'admin') {
        window.location.href = 'admin.html'; // Redirect to admin page
      } else {
        window.location.href = 'user.html'; // Redirect to user page or any other user-specific screen
      }
    })
    .catch((error) => {
      alert(error.message);
    });
});


    testButtons.forEach(btn => {
        btn.addEventListener('click', function(event) {
            event.preventDefault();
            const chapter = this.getAttribute('href').split('#')[1];
            const testForm = document.getElementById(`${chapter}-form`);
            testForm.style.display = 'block';
            testForm.scrollIntoView({ behavior: 'smooth' });
        });
    });
});

// Signup function
document.getElementById('signup-form').addEventListener('submit', function (event) {
  event.preventDefault();

  const email = event.target['signup-email'].value;
  const password = event.target['signup-password'].value;
  const confirmPassword = event.target['confirm-password'].value;
  const userRole = event.target['user-role'].value; // Get user role

  if (password !== confirmPassword) {
    alert('Passwords do not match!');
    return;
  }

  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      alert(`Sign up successful! Role: ${userRole}`);

      // If the role is admin, redirect to login screen
      if (userRole === 'admin') {
        showLogin(); // This will switch to the login form
      }

      // You can store the user role in your database or perform role-based logic here if needed
    })
    .catch((error) => {
      alert(error.message);
    });
});


document.addEventListener('DOMContentLoaded', function() {
    const testForms = document.querySelectorAll('.test-form');

    testForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            const chapter = window.location.hash.substring(1);
            const answers = Array.from(form.elements).filter(elem => elem.type === 'radio' && elem.checked);
            const data = {};
            answers.forEach(answer => {
                data[answer.name] = answer.value;
            });
            // You can add your test submission logic here
            console.log('Chapter:', chapter);
            console.log('Answers:', data);
            form.reset();
        });
    });
    
    
});
